import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
Name:string;
Bio:string;
  constructor() { }

  ngOnInit() {
  }

  Add(formValues:any){
    console.log(formValues);
    this.Name=formValues.Name;
    this.Bio=formValues.Bio;
    console.log(this.Name+","+this.Bio);
  }
}
